<?php
	$dbHost = "localhost";
	$dbUser = "homestead";
	$dbPass = "secret";
	$dbName = "project";
?>